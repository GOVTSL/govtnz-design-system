# Patterns (coming soon)

Help users by using our patterns which provide easy action flows for specific tasks, as well as templates for common forms.
Typical examples include collecting users' address and contact details, and
guiding users through a step-by-step application form.

We'll be inviting you to co-design some patterns with us soon. To keep updated
with what we are doing now, what we are planning to do next, and how you can
get involved, [subscribe to the New Zealand Government Design System (NZGDS) newsletter](https://confirmsubscription.com/h/j/712F84D0A3086D2B).
