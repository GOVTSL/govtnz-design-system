# Basics

Basic design elements apply to all parts of a website. Key basic elements provided by the New Zealand Government Design System (NZGDS) include typography and colour guidance for interaction design. Additional basic elements are coming soon.

Browse available basics via the sidebar menu if you’re on a desktop, or the main menu if you’re using a mobile.
