<ExampleContainer>
    <ExampleHeading>Example of File Upload</ExampleHeading>
    <Example title="Example: File upload">
        <FileUpload />
    </Example>
</ExampleContainer>

## Credit

Guidance, original HTML and CSS derived from [GOV.UK Design System](https://github.com/alphagov/govuk-frontend).
