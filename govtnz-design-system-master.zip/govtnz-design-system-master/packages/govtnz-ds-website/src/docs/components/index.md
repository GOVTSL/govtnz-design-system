As key building blocks of the New Zealand Government Design System (NZGDS), our components are designed and coded to solve specific user problems.

Choose what you need from our catalogue of modular components. Using them saves you the time and cost of developing and testing complex components yourself. Designed to integrate directly into existing content management systems, these components will add functionality to your website without you having to rebuild it.

Browse available components via the sidebar menu if you’re on a desktop, or the main menu if you’re using a mobile.
