<ExampleContainer>
    <ExampleHeading>Example of Inset Text</ExampleHeading>
    <Example title="Example: Inset text">
        <InsetText />
    </Example>
</ExampleContainer>

## Credit

Guidance, original HTML and CSS derived from [GOV.UK Design System](https://github.com/alphagov/govuk-frontend).
