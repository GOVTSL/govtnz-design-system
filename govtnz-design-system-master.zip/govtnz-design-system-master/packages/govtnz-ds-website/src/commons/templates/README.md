These files are used by govtnz-ds-website/prebuild/prebuild.js as source code templates.
