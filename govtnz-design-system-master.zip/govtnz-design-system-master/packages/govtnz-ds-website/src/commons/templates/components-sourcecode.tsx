// These values are dynamically replaced in prebuild.js.
export const id: any = '{{id}}'
export const templateFormats: any = '{{templateFormats}}'
export const formats: string[] = Object.keys(templateFormats)
