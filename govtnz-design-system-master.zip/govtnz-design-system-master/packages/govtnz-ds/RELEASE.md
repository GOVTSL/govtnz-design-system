# Infra Docs

See https://design-system-alpha.digital.govt.nz for production website.

## Install

See `/CONTRIBUTING.md` for install instructions.

## Deploy branches

| Branch           | Description               |
| ---------------- | ------------------------- |
| `deploy/alpha`   | Production site for Alpha |
| `deploy/preview` | Preview site (pre-prod).  |

Preview site URL is intentionally unlinked from these docs.

## Tasks

* Jira (URL intentionally unlinked from these docs)
