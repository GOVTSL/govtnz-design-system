# Settings

The `_settings.json` file is to assist 3rd-party integrations (ie. CMS) to know which variables are being used.